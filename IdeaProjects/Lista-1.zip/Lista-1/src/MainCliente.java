import exe2.Cliente;

public class MainCliente {
    public static void main(String[] args) {

        Cliente obj1 = new Cliente();

        Cliente obj2 = new Cliente(123, 456, "Thiago", 1500.42f);
    }
}